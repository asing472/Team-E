﻿using Pecunia.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pecunia.Contracts.BLContracts
{
    public interface IFixedBL : IDisposable
    {
        Task<bool> CreateAccountBL(Fixed newfixed);
        Task<List<Fixed>> GetAllAccountsBL();
        Task<Fixed> SearchAccountByAccountNoBL(string searchAccountNo);
        Task<List<Fixed>> GetAccountsByCustomerNoBL(string searchCustomerNo);
        Task<List<Fixed>> GetAccountsByBranchBL(string searchBranch);
        Task<List<Fixed>> GetAccountsByAccountOpeningDateBL(DateTime d1, DateTime d2);
        Task<double> GetBalanceBL(string accountNumber);
        Task<bool> UpdateBalanceBL(string accountNumber, double balance);
        Task<bool> UpdateBranchBL(string accountNumber, string branch);
        Task<bool> DeleteAccountBL(string deleteAccountNo);
    }
}
