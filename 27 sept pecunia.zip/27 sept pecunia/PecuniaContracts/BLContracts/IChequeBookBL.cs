﻿using Pecunia.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pecunia.Contracts.BLContracts
{
    public interface iChequeBookBL : IDisposable
    {

        Task<bool> AddChequeBookBL(ChequeBook chequeBook);
        Task<List<ChequeBook>> GetAllChequeBooksBL();
        Task<bool> UpdateChequeBookStatusBL(string chequeBookId);
        Task<List<ChequeBook>> GetChequeBooksByAccountIdBL(Guid accountId);
        Task<ChequeBook> GetChequeBookByChequeBookIdBL(string chequeBookId);


    }
}
