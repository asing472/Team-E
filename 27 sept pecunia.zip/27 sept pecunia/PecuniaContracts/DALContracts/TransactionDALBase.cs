﻿using Newtonsoft.Json;
using Pecunia.Entities;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pecunia.Contracts.DALContracts
{
    /// <summary>
    /// This class acts as a base class for the TransactionDAL Class. 
    /// </summary>
    public abstract class TransactionDALBase
    {
        // Collection of all Transactions.
        protected static List<Transaction> TransactionList = new List<Transaction>();
        private static string fileName = "Transaction.json";

        //methods for operation
        public abstract bool AddTransactionDAL(Transaction newTransaction);
        public abstract List<Transaction> GetAllTransactionsDAL();
        public abstract List<Transaction> GetAllTransactionsByTransactionTypeDAL(string transactionType);
        public abstract List<Transaction> GetAllTransactionsByAccountNumberDAL(string accountNumber);
        public abstract List<Transaction> GetAllTransactionsByTimeDAL(DateTime transactionTime);

        /// <summary>
        /// Writes collection to the file in JSON format.
        /// </summary>
        public static void Serialize()
        {
            string serializedJson = JsonConvert.SerializeObject(TransactionList);
            using (StreamWriter streamWriter = new StreamWriter(fileName))
            {
                streamWriter.Write(serializedJson);
                streamWriter.Close();
            }
        }

        /// <summary>
        /// Reads collection from the file in JSON format.
        /// </summary>
        public static void Deserialize()
        {
            string fileContent = string.Empty;
            if (!File.Exists(fileName))
                File.Create(fileName).Close();

            using (StreamReader streamReader = new StreamReader(fileName))
            {
                fileContent = streamReader.ReadToEnd();
                streamReader.Close();
                var TransactionListFromFile = JsonConvert.DeserializeObject<List<Transaction>>(fileContent);
                if (TransactionListFromFile != null)
                {
                    TransactionList = TransactionListFromFile;
                }
            }
        }

        /// <summary>
        /// Static Constructor.
        /// </summary>
        static TransactionDALBase()
        {
            Deserialize();
        }

    }

}
