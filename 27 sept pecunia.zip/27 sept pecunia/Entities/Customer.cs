﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pecunia.Helpers.ValidationAttribute;
using PecuniaHelpers;

namespace Pecunia.Entities
{
    /// <summary>
    /// Interface for Customer Entity
    /// </summary>
    public interface ICustomer
    {
        Guid CustomerID { get; set; }
        string CustomerNumber { get; set; }
        string CustomerName { get; set; }
        string CustomerMobile { get; set; }
        string CustomerAddress { get; set; }
        string CustomerAadharNumber { get; set; }
        string CustomerPANNumber { get; set; }
        Gender CustomerGender { get; set; }
        DateTime CustomerDOB { get; set; }
        string Email { get; set; }
        double WorkExperience { get; set; }
        double AnnualIncome { get; set; }
        DateTime CreationDateTime { get; set; }
        DateTime LastModifiedDateTime { get; set; }
    }


    /// <summary>
    /// Represents Customer
    /// </summary>
    public class Customer : ICustomer
    {
        /* Auto-Implemented Properties */
        //[Required("Customer ID can't be blank.")]
        public Guid CustomerID { get; set; }

        //[Required("Customer Number can't be blank.")]
        public string CustomerNumber { get; set; }

        [Required("Customer Name can't be blank.")]
        [RegExp(@"^(\w{2,40})$", "Customer Name should contain only 2 to 40 characters.")]
        public string CustomerName { get; set; }

        [RegExp(@"^[6789]\d{9}$", "Mobile number should contain 10 digits")]
        public string CustomerMobile { get; set; }

        [Required("Email can't be blank.")]
        [RegExp(@"\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*", "Email is invalid.")]
        public string Email { get; set; }

        [RegExp(@"^(\w{5,200})$", "Customer Address should contain 5 to 200 characters.")]
        public string CustomerAddress { get; set; }

        [RegExp(@"^(\d{12})$", "Aadhar number should contain 12 digits.")]
        public string CustomerAadharNumber { get; set; }

        [RegExp(@"^[A-Z]{5}[0-9]{4}[A-Z]{1}$", "PAN number is invalid.")]
        public string CustomerPANNumber { get; set; }


        [Required("Gender can't be blank.")]
        public Gender CustomerGender { get; set; }


        [Required("Customer DOB can't be blank.")]
        public DateTime CustomerDOB { get; set; }


        [RegExp(@"^[+]?([0-9]+(?:[\.][0-9]*)?|\.[0-9]+)$", "Work experience is invalid.")]
        public double WorkExperience { get; set; }

        [RegExp(@"^[+]?([0-9]+(?:[\.][0-9]*)?|\.[0-9]+)$", "Annual Income is invalid.")]
        public double AnnualIncome { get; set; }


        public DateTime CreationDateTime { get; set; }
        public DateTime LastModifiedDateTime { get; set; }

        /* Constructor */
        public Customer()
        {
            CustomerID = default(Guid);
            CustomerName = null;
            CustomerMobile = null;
            Email = null;
            CustomerAddress = null;
            CustomerPANNumber = null;
            CustomerAadharNumber = null;
            CustomerDOB = default(DateTime);
            WorkExperience = 0;
            AnnualIncome = 0;

            CreationDateTime = default(DateTime);
            LastModifiedDateTime = default(DateTime);
        }
    }
}





