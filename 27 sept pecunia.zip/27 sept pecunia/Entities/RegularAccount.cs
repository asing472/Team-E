﻿using Pecunia.Helpers.ValidationAttribute;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Pecunia.Entities
{

    /// <summary>
    /// Interface for Regular Account Entity
    /// </summary>
    public interface IRegularAccount
    {

        Guid AccountID { get; set; }
        Guid CustomerID { get; set; }
        string CustomerNo { get; set; }
        string AccountNo { get; set; }
        double CurrentBalance { get; set; }
        string AccountType { get; set; }
        string Branch { get; set; }
        string Status { get; set; }
        double MinimumBalance { get; set; }
        double InterestRate { get; set; }
        DateTime CreationDateTime { get; set; }
        DateTime LastModifiedDateTime { get; set; }

    }

    /// <summary>
    /// Represents Savings and Current Account
    /// </summary>
    public class RegularAccount : IRegularAccount
    {

        /*Auto-Imlemented Properties*/
        [Required("Account ID can't be blank.")]
        public Guid AccountID { get; set; }

        [Required("Customer ID can't be blank.")]
        public Guid CustomerID { get; set; }
        [Required("Customer No can't be blank.")]
        public string CustomerNo { get; set; }
        
        public string AccountNo { get; set; }

        [Required("Current Balance can't be negative.")]
        [RegExp(@"^[+]?([0-9]+(?:[\.][0-9]*)?|\.[0-9]+)$", "Current Balance is invalid.")]
        public double CurrentBalance { get; set; }

        [Required("Account Type can't be blank")]
        public string AccountType { get; set; }

        [Required("Branch can't be blank.")]
        public string Branch { get; set; }

        public string Status { get; set; }

        [Required("Minimum Balance can't be negative.")]
        [RegExp(@"^[+]?([0-9]+(?:[\.][0-9]*)?|\.[0-9]+)$", "Minimum Balance is invalid.")]
        public double MinimumBalance { get; set; }

        [Required("Interest Rate can't be negative.")]
        [RegExp(@"^[+]?([0-9]+(?:[\.][0-9]*)?|\.[0-9]+)$", "Interest Rate is invalid.")]
        public double InterestRate { get; set; }

        public DateTime CreationDateTime { get; set; }
        public DateTime LastModifiedDateTime { get; set; }

        /*Constructor*/
        public RegularAccount()
        {
            AccountID = default(Guid);
            CustomerID = default(Guid);
            AccountNo = null;
            CurrentBalance = 0;
            AccountType = null;
            Branch = null;
            MinimumBalance = 0;
            InterestRate = 0;
            Status = "Active";
            CreationDateTime = default(DateTime);
            LastModifiedDateTime = default(DateTime);

        }

    }

}

