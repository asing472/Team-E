﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using Pecunia.BusinessLayer;
using Pecunia.Contracts.BLContracts;
using Pecunia.Exceptions;
using Pecunia.Entities;

namespace Pecunia.PresentationLayer
{
    public static class CustomerPresentation

    {
        /// <summary>
        /// Menu for Customer
        /// </summary>
        /// <returns></returns>
        public static async Task<int> CustomerMenu()
        {
            int choice = -2;

            do
            {
                CustomerBL cbl = new CustomerBL();
                //Menu
                WriteLine("\n***************Employee***********");
                WriteLine("1. View Customers List ");
                WriteLine("2. Add Customer ");
                WriteLine("3. Search Customer By CustomerNumber ");
                WriteLine("4. Update Customer Details ");
                WriteLine("5. Serialize ");

                WriteLine("0. Logout");
                WriteLine("-1. Exit");
                Write("Choice: ");
                //Accept and check choice
                bool isValidChoice = int.TryParse(ReadLine(), out choice);
                if (isValidChoice)
                {
                    switch (choice)
                    {
                        case 1: await ViewCustomersList(); break;
                        case 2: await AddCustomer(); break;
                        case 3: await SearchCustomerByCustomerNumber(); break;
                        case 4: await UpdateCustomerDetails(); break;
                        case 5:
                            if(await cbl.serialize())
                            Console.WriteLine("Sucessfully Serialized"); break;

                    }
                }
                else
                {
                    choice = -2;
                }
            } while (choice != 0 && choice != -1);
            return choice;
        }



        /// <summary>
        /// Displays list of Customers.
        /// </summary>
        /// <returns></returns>
        public static async Task ViewCustomersList()
        {
            try
            {
                using (ICustomerBL icustomerBL = new CustomerBL())
                {
                    //Get and display list of customers.
                    List<Customer> customers = await icustomerBL.GetAllCustomersBL();
                    WriteLine("Customers List: ");
                    if (customers != null && customers?.Count > 0)
                    {
                        WriteLine("#\t Name of Customer\t Mobile number\t Email ID\t Gender\tCustomer ID\t Customer Number\t Last Modified date time");
                        int serial = 0;
                        foreach (var customer in customers)
                        {
                            serial++;
                            WriteLine($"{serial}\t{customer.CustomerName}\t{customer.CustomerMobile}\t{customer.Email}\t{customer.CustomerGender}\t{customer.CustomerID}\t{customer.CustomerNumber}\t{customer.LastModifiedDateTime}");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionLogger.LogException(ex);
                WriteLine(ex.Message);
            }
        }
        /// <summary>
        /// Adds Customer.
        /// </summary>
        /// <returns></returns>
        public static async Task AddCustomer()
        {
            try
            {
                //Read inputs
                Customer customer = new Customer();
                Write("Name:  ");
                customer.CustomerName = ReadLine();
                Write("Mobile number:  ");
                customer.CustomerMobile = ReadLine();
                Write("Email ID:  ");
                customer.Email = ReadLine();
                Write("Aadhar Number:  ");
                customer.CustomerAadharNumber = ReadLine();
                Write("PAN Number:  ");
                customer.CustomerPANNumber = ReadLine();
                Write("Address:  ");
                customer.CustomerAddress = ReadLine();
                Write("DOB (in yyyy/MM/DD format) : ");
                customer.CustomerDOB = Convert.ToDateTime(ReadLine());
                Write("Gender:  ");
                string gen = ReadLine();
                // Write("CustomerNumber:  ");
                //customer.CustomerNumber = ReadLine();
                if (gen.Equals("Male", StringComparison.OrdinalIgnoreCase))
                {
                    customer.CustomerGender = PecuniaHelpers.Gender.Male;
                }
                else if (gen.Equals("Female", StringComparison.OrdinalIgnoreCase))
                {
                    customer.CustomerGender = PecuniaHelpers.Gender.Female;
                }
                else
                {
                    customer.CustomerGender = PecuniaHelpers.Gender.Transgender;
                }

                Write("AnnualIncome:  ");
                customer.AnnualIncome =Convert.ToDouble( ReadLine());
                Write("Work Experience:  ");
                customer.WorkExperience = Convert.ToDouble(ReadLine());
                //Invoke AddCustomerBL method to add
                using (ICustomerBL customerBL = new CustomerBL())
                {
                    bool isAdded = await customerBL.AddCustomerBL(customer);
                    if (isAdded)
                    {
                        WriteLine("Customer Added");
                       customer.CustomerNumber = DateTime.Now.ToString("yyyyMMddHH");
                        WriteLine("Customer No.generated is: " + customer.CustomerNumber);
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionLogger.LogException(ex);
                WriteLine(ex.Message);
            }
        }
        /// <summary>
        /// Searches Customer By CustomerNumber.
        /// </summary>
        /// <returns></returns>
        public static async Task SearchCustomerByCustomerNumber()
        {
            try
            {
                //Read inputs

                WriteLine("Enter Customer Number  ");
                string searchCustomerNumber = ReadLine();
                CustomerBL customerBL = new CustomerBL();
                Customer customer = new Customer();
                customer = await customerBL.GetCustomerByCustomerNumberBL(searchCustomerNumber);

                //Invoke SearchCustomerByCustomerNumberBL method to search
                using (ICustomerBL icustomerBL = new CustomerBL())
                {
                    Customer CustomerByCustomerNumber = new Customer();
                    CustomerByCustomerNumber = await icustomerBL.GetCustomerByCustomerNumberBL(customer.CustomerNumber);
                    if (CustomerByCustomerNumber != null)
                    {
                        WriteLine("Customer found ");
                        Console.WriteLine("******************************************************************************");
                        Console.WriteLine("CustomerNumber\t\tCustomer ID\t\tName\t\tPhoneNumber");
                        Console.WriteLine("******************************************************************************");
                        Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}", CustomerByCustomerNumber.CustomerNumber, CustomerByCustomerNumber.CustomerID, CustomerByCustomerNumber.CustomerName, CustomerByCustomerNumber.CustomerMobile);
                        Console.WriteLine("******************************************************************************");
                    }
                    else
                    {
                        WriteLine("Customer not found ");
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionLogger.LogException(ex);
                WriteLine(ex.Message);
            }
        }
        /// <summary>
        /// Updates Customer details.
        /// </summary>
        /// <returns></returns>
        public static async Task UpdateCustomerDetails()
        {
            try
            {
                //Read inputs

                WriteLine("Enter Customer number ");
                string customerNumber = ReadLine();
                CustomerBL customerBL = new CustomerBL();
                Customer updatecustomer = await customerBL.GetCustomerByCustomerNumberBL(customerNumber);
                if (updatecustomer != null)
                {
                    Console.WriteLine("Update Customer Name : ");
                    updatecustomer.CustomerName = Console.ReadLine();
                    Console.WriteLine("Update PhoneNumber : ");
                    updatecustomer.CustomerMobile = Console.ReadLine();
                    Console.WriteLine("Update Email ID : ");
                    updatecustomer.Email = Console.ReadLine();
                    Console.WriteLine("Update Address : ");
                    updatecustomer.CustomerAddress = Console.ReadLine();
                    //Invokes UpdateCustomerBL to  update customer details
                    bool customerUpdated = await customerBL.UpdateCustomerBL(updatecustomer);
                    if (customerUpdated)
                        Console.WriteLine("Customer Details Updated");
                    else
                        Console.WriteLine("Customer Details not Updated ");
                }
                else
                {
                    Console.WriteLine("No customer Details Available");
                }


            }
            catch (Exception ex)
            {
                ExceptionLogger.LogException(ex);
                WriteLine(ex.Message);
            }
        }



    }
}